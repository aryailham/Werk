package com.example.werk;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.LinearLayout;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.RecyclerView;

import com.example.werk.model.AvailableJobs;

import java.util.ArrayList;

public class RecyclerAdapter extends RecyclerView.Adapter<RecyclerAdapter.RecyclerViewHolder> {
    ArrayList<AvailableJobs> arrayList = new ArrayList<AvailableJobs>();
    Fragment c;

    public RecyclerAdapter(ArrayList<AvailableJobs> arrayList, Fragment c) {
        this.arrayList = arrayList;
        this.c = c;
    }

    RecyclerAdapter(ArrayList<AvailableJobs> arrayList)
    {
        this.arrayList = arrayList;
    }


    @Override
    public RecyclerViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.list_avail_jobs, parent, false);

        RecyclerViewHolder holder = new RecyclerViewHolder(view);
        return holder;
    }

    @Override
    public void onBindViewHolder(@NonNull final RecyclerViewHolder holder, int position) {
        final AvailableJobs availableJobs = arrayList.get(position);
        holder.tvJobTitle.setText(availableJobs.getJobTitle());
        holder.tvCompanyName.setText(availableJobs.getCompanyName());
        holder.tvCompanyAdress.setText(availableJobs.getCompanyAdress());
        holder.tvJobSalary.setText("Rp"+String.valueOf(availableJobs.getSalaryLower())+" - Rp"+String.valueOf(availableJobs.getSalaryUpper()));
        holder.tvApplicantCount.setText(String.valueOf(availableJobs.getApplicantCount()) + " Applicant"); //Integer.toString(availableJobs.getApplicantCount()));

//        holder.conJobList.setOnClickListener(new View.OnClickListener() {
//            @Override
//            public void onClick(View v) {
//                String jobVacancyId = String.valueOf(availableJobs.getJobVacancyId());
//
//                Bundle bundle = new Bundle();
//                bundle.putString("jobId", jobVacancyId);
//
//                FragmentManager fragmentManager = c.getActivity().getSupportFragmentManager();
//                FragmentTransaction fragmentTransaction = fragmentManager.beginTransaction();
//
//                JobDetailFragment jobDetailFragment = new JobDetailFragment();
//                jobDetailFragment.setArguments(bundle);
//
//                fragmentTransaction.replace(R.id.container, jobDetailFragment);
//                fragmentTransaction.commit();
//
//
//            }
//        });



    }

    @Override
    public int getItemCount() {
        return arrayList.size();
    }

    public static class RecyclerViewHolder extends RecyclerView.ViewHolder
    {
        TextView tvJobTitle, tvCompanyAdress, tvCompanyName, tvJobSalary, tvApplicantCount;
        LinearLayout conJobList;

        RecyclerViewHolder(View view)
        {
            super(view);
            tvJobTitle = (TextView)view.findViewById(R.id.job_title);
            tvJobSalary = (TextView)view.findViewById(R.id.job_salary);
            tvCompanyName = (TextView)view.findViewById(R.id.company_name);
            tvCompanyAdress = (TextView)view.findViewById(R.id.company_address);
            tvApplicantCount = (TextView) view.findViewById(R.id.applicant_count);
            conJobList = (LinearLayout) view.findViewById(R.id.con_job_list);

        }


    }
}
